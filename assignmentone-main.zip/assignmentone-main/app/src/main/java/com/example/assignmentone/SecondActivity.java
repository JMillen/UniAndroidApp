package com.example.assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import java.util.Random;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }


    //Creates an on click method which opens the FunFactActivity.
    public void onClick(View v){
        //Generates a random number between 0-7
        Random random = new Random();
        int randomNumber = random.nextInt(8);

        //Attach the random number as extra data with the key "RandomNumber"
        Intent intent = new Intent(this, FunFactActivity.class);
        intent.putExtra("RandomNumber", randomNumber);

        startActivity(intent);
    }
}