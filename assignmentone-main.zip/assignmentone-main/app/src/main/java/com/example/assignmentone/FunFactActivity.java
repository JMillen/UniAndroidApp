package com.example.assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class FunFactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fun_fact);

        //Extracts random number extra with the key "RandomNumber"
        //Defaults to 0 if there is no data
        Intent intent = getIntent();
        int randomNumber = intent.getIntExtra("RandomNumber",0);


        String[] funFactsText = getResources().getStringArray(R.array.string_array_fun_facts_text);
        String[] funFactsImg = getResources().getStringArray(R.array.string_array_fun_facts_images);

        //Find TextView & ImageView on activity_fun_fact by id
        TextView textView = findViewById(R.id.textView_funFact);
        ImageView imageView = findViewById(R.id.imgView_funFact);

        //Checks random number is within bounds
        if(randomNumber >= 0 && randomNumber <= funFactsText.length){
            //Choose a random img & text from arrays using random number generated
            String chosenText = funFactsText[randomNumber];
            String chosenImage = funFactsImg[randomNumber];

            //Set text
            textView.setText(chosenText);
            //Set image
            int imageID = getResources().getIdentifier(chosenImage, "drawable", getPackageName());
            imageView.setImageResource(imageID);
        }
    }
}